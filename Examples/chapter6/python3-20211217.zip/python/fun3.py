# return
  
def my_function2(fname,sname):
  return fname+' '+sname

var1=''
var1=input("Enter your first name please:")
 
var2=input("Enter your second name please:")
fullname=my_function2(var1,var2)
print(fullname)



