def evenOdd(n):
    if n%2==0:
        print(str(n)+" is even")
    else:
        print(str(n)+" is odd")

x=int(input("ENTER AN INTEGER: "))

evenOdd(x)



    
