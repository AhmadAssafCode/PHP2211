char='+'

while(char!='e'):
    a=int(input("ENTER FIRST NUMBER: "))
    b=int(input("ENTER SECOND NUMBER: "))
    print(str(a)+"+"+str(b)+"="+str(a+b))
    char=input("ENTER + OR e TO END: ")
print("GOOD BYE!")
