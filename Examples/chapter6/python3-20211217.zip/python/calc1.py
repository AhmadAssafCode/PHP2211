a=0
while(a!=-1):
    a=int(input("ENTER A NUMBER: "))
    #if a==-1:
       # break
    b=int(input("ENTER A NUMBER: "))
    print(str(a)+"+"+str(b)+"="+str(a+b))
print("GOOD BYE!")
