def evenOdd(n):
    if n%2==0:
        return "Tarneem"
     
    else:
        return "ODD"
      

x=int(input("ENTER AN INTEGER: "))

print(str(x) +" is "+ evenOdd(x))



    
