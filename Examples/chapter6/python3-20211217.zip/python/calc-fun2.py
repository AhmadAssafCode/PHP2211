def myAdd(x,y):
    return x+y
def mySub(x,y):
    return x-y



a=int(input("Enter a number: "))
b=int(input("Enter a number: "))
print("The sum="+str(myAdd(a,b)))
print("The substract="+str(mySub(a,b)))

