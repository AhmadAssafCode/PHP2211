n=0
while(n!=-1):
    n=int(input("ENTER A NUMBER: "))

    if(n%2==0):
        print(str(n)+" is even!")
    else:
        print(str(n)+" is odd!")

print("GOOD BYE!")
