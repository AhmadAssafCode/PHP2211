
d=int(input("أدخل رقم اليوم:"))

if(d==1):
    print("الاحد")
elif(d==2):
    print("الاثنين")
elif(d==3):
    print("الثلاثاء")
elif(d==4):
    print("الاربعاء")
elif(d==5):
    print("الخميس")
elif(d==6):
    print("الجمعة")
elif(d==7):
    print("السبت")
else:
    print("ادخل رقم يوم صحيح 1-7")



